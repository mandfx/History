AdvanceSettings_for_BaiduROM
==========================
这个apk专门百度os写的 可以通过简配置xml来加入高级设置
