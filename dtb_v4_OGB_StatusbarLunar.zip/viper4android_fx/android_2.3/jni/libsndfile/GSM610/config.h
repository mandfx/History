#ifndef	CONFIG_H
#define	CONFIG_H

#define	HAS_STDLIB_H	1
#define	HAS_FCNTL_H		1
#define	HAS_FSTAT 		1
#define	HAS_FCHMOD 		1
#define	HAS_CHMOD 		1
#define	HAS_FCHOWN 		1
#define	HAS_CHOWN 		1
#define	HAS_STRING_H 	1
#define	HAS_UNISTD_H	1
#define	HAS_UTIME		1
#define	HAS_UTIME_H		1

#endif
