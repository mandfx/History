# dtimg2dtb-python
Extract dtb files from dt image

usage:
---------
     python dtimg2dtb.py <input_dt_image> <output_dtb_path>

example:
---------
     python dtimg2dtb.py dt.img
     python dtimg2dtb.py dt.img ./dtb

![image](https://github.com/wuxianlin/dtimg2dtb-python/raw/master/screenshots/example1.png)
