<h>OGBatteryMod</h>
============
Programmed by : Osama Ghareeb
<br />
Thread on XDA : <a href="http://forum.xda-developers.com/showthread.php?t=2181766">[Modding App] OGBatteryMod  (No Root)(Android 2.3 - 4.2.2)</a> 


