/** Automatically generated file. DO NOT MODIFY */
package com.ghareeb.battery;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}